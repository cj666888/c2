<?php

namespace addons\exam\model;


class NoticeModel extends \app\admin\model\exam\NoticeModel
{
    protected $type = [
        'front_info' => 'json',
    ];
}
