<?php

namespace addons\exam\enum;

/**
 * 通用状态
 */
class GeneralStatus extends BaseEnum
{
    /** 正常 */
    const NORMAL = 1;
    /** 禁用 */
    const DISABLE = 0;
}
