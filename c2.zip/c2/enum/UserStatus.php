<?php

namespace addons\exam\enum;

/**
 * 用户状态
 */
class UserStatus extends BaseEnum
{
    /** 正常 */
    const NORMAL = 'normal';
    /** 隐藏 */
    const HIDDEN = 'hidden';
}
