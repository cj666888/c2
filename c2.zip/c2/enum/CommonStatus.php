<?php

namespace addons\exam\enum;

/**
 * 常用状态
 */
class CommonStatus extends BaseEnum
{
    /** 正常 */
    const NORMAL = 'NORMAL';
    /** 隐藏 */
    const HIDDEN = 'HIDDEN';
}
