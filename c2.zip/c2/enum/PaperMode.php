<?php

namespace addons\exam\enum;

/**
 * 试卷选题模式
 */
class PaperMode extends BaseEnum
{
    /** 随机 */
    const RANDOM = 'RANDOM';
    /** 固定 */
    const FIX = 'FIX';
}
