<?php

namespace addons\exam\enum;

/**
 * 试卷可用群体
 */
class CateUses extends BaseEnum
{
    /** 所有用户可用 */
    const ALL = 'ALL';
    /** 会员专用 */
    const ONLY_MEMBER = 'ONLY_MEMBER';
}
