<?php

namespace addons\exam\enum;

/**
 * 积分变动种类
 */
class UserScoreKind extends BaseEnum
{
    /** 增加 */
    const INC = 'INC';
    /** 减少 */
    const DEC = 'DEC';
}
