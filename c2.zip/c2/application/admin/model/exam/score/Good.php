<?php

namespace app\admin\model\exam\score;

use think\Model;

class Good extends Model
{
    // 表名
    protected $name = 'exam_score_good';
    
}
