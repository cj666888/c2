<?php

namespace app\admin\model\exam\cert;

use think\Model;

class Template extends Model
{
    // 表名
    protected $name = 'exam_cert_template';
    
}
