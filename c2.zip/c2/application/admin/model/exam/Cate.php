<?php

namespace app\admin\model\exam;

use think\Model;

class Cate extends Model
{
    // 表名
    protected $name = 'exam_cate';
    
}
