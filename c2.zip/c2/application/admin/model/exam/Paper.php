<?php

namespace app\admin\model\exam;

use think\Model;

class Paper extends Model
{
    // 表名
    protected $name = 'exam_paper';
    
}
