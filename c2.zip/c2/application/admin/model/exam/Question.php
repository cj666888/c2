<?php

namespace app\admin\model\exam;

use think\Model;

class Question extends Model
{
    // 表名
    protected $name = 'exam_question';
    
}
