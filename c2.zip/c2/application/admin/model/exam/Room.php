<?php

namespace app\admin\model\exam;

use think\Model;

class Room extends Model
{
    // 表名
    protected $name = 'exam_room';
    
}
