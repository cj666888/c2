<?php

return [
    'Cert_config_id' => '所属证书配置',
    'Name'           => '名称',
    'Min_score'      => '证书最低分数',
    'Image'          => '证书图片',
    'Field_config'   => '字段配置',
    'Status'         => '状态',
    'Status 0'       => '禁用',
    'Status 1'       => '启用',
    'Createtime'     => '创建时间',
    'Updatetime'     => '修改时间',
    'Deletetime'     => '删除时间',
    'Config.name'    => '名称'
];
