<?php

return [
    'Name'       => '类型名称',
    'Createtime' => '创建时间',
    'Updatetime' => '修改时间'
];
