<?php

return [
    'Name'              => '按钮名称',
    'page_style'        => '所属页面风格',
    'page_style color'  => '多彩风格1',
    'page_style color2' => '多彩风格2',
    'page_style simple' => '精简风格',
    'Type'              => '图标展示方式',
    'Type icon'         => '图标',
    'Type image'        => '图片',
    'Icon'              => '按钮图标',
    'color'             => '图标颜色',
    'bg_color'          => '背景颜色',
    'Image'             => '按钮图片',
    'Path'              => '跳转页面',
    'Weigh'             => '排序',
    'Status'            => '状态',
    'Status 0'          => '禁用',
    'Set status to 0'   => '设为禁用',
    'Status 1'          => '启用',
    'Set status to 1'   => '设为启用',
    'Createtime'        => '创建时间',
    'Updatetime'        => '修改时间'
];
