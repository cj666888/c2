<?php

return [
    'Ad_config'     => '广告位配置',
    'System_config' => '系统配置',
    'Wx_config'     => '微信配置'
];
