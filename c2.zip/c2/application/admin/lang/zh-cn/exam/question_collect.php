<?php

return [
    'User_id'        => '用户',
    'Question_id'    => '试题',
    'Createtime'     => '创建时间',
    'Updatetime'     => '修改时间',
    'Question.title' => '题目'
];
