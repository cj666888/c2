<?php

return [
    'Id'             => 'ID',
    'User_id'        => '支付用户',
    'Order_no'       => '订单编号',
    'Amount'         => '订单金额',
    'Type'           => '用户类型',
    'Type vip_month' => '月卡会员',
    'Type vip_year'  => '年卡会员',
    'Type vip_life'  => '终身会员',
    'Status'         => '是否已支付',
    'Status 0'       => '否',
    'Status 1'       => '是',
    'Pay_money'      => '支付金额',
    'Pay_time'       => '支付时间',
    'Createtime'     => '创建时间',
    'Updatetime'     => '更新时间',
    'User.nickname'  => '昵称',
    'User.avatar'    => '头像'
];
