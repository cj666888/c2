<?php

return [
    'Name'               => '名称',
    'Image'              => '图标',
    'Miniapp_code_image' => '小程序码图片',
    'Wx_app_id'          => '小程序APPID',
    'Status'             => '状态',
    'Status 0'           => '禁用',
    'Status 1'           => '启用',
    'Weigh'              => '排序'
];
