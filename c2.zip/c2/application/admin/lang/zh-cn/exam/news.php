<?php

return [
    'Images'      => '图片',
    'Cover_image' => '封面',
    'Name'        => '标题',
    'Contents'    => '内容',
    'Weigh'       => '排序',
    'Status'      => '状态',
    'Front_info'  => '前端跳转信息',
    'Createtime'  => '创建时间',
    'Updatetime'  => '修改时间'
];
