<?php

return [
    'Name'       => '名称',
    'Remark'     => '说明',
    'Status'     => '状态',
    'Status 0'   => '禁用',
    'Status 1'   => '启用',
    'Createtime' => '创建时间',
    'Updatetime' => '修改时间',
    'Deletetime' => '删除时间'
];
