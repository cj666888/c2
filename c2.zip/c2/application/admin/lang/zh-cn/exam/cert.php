<?php

return [
    'Cert_config_id'   => '证书配置',
    'Cert_template_id' => '证书模板',
    'User_id'          => '所属用户',
    'Paper_id'         => '所属试卷',
    'user_name'        => '姓名',
    'Score'            => '考试分数',
    'Image'            => '证书图片',
    'Status'           => '状态',
    'Status 0'         => '失效',
    'Status 1'         => '正常',
    'Source'           => '来源',
    'Source paper'     => '试卷考试',
    'Source room'      => '考场考试',
    'Source manual'    => '手动创建',
    'Expire_time'      => '过期时间',
    'Createtime'       => '创建时间',
    'Updatetime'       => '修改时间',
    'Deletetime'       => '删除时间',
    'Config.name'      => '名称',
    'Template.name'    => '名称',
    'User.nickname'    => '昵称',
    'Paper.title'      => '试卷名称'
];
