<?php

return [
    'Cate_id'       => '题库ID',
    'User_id'       => '激活用户',
    'Type'          => '状态',
    'Type pay'      => '支付订单',
    'Type code'     => '激活码',
    'Expire_time'   => '过期时间',
    'Createtime'    => '创建时间',
    'Updatetime'    => '修改时间',
    'User.nickname' => '昵称',
    'Cate.name'     => '名称'
];
