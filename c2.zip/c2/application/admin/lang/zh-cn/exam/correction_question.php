<?php

return [
    'User_id'        => '反馈人',
    'Question_id'    => '反馈题目',
    'Type_ids'       => '纠错类型',
    'Type_names'     => '类型名称',
    'Remark'         => '其他说明',
    'Status'         => '状态',
    'Status 0'       => '未处理',
    'Status 1'       => '已处理',
    'Status 2'       => '忽略',
    'Message'        => '处理说明',
    'Createtime'     => '创建时间',
    'Updatetime'     => '修改时间',
    'Question.title' => '题目',
    'User.nickname'  => '昵称'
];
