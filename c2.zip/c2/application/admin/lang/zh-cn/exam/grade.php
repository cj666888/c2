<?php

return [
    'Cate_id'     => '所属分类',
    'User_id'     => '考试用户',
    'Paper_id'    => '所属试卷',
    'Score'       => '考试分数',
    'Is_pass'     => '是否及格',
    'Total_score' => '总分数',
    'Total_count' => '总题数',
    'Right_count' => '答对数',
    'Error_count' => '答错数',
    'Grade_time'  => '考试用时',
    'Createtime'  => '创建时间',
    'Updatetime'  => '修改时间',
    'Cate.name'   => '名称',
    'Paper.title' => '试卷名称'
];
