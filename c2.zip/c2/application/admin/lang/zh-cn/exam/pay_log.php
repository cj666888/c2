<?php

return [
    'Id'             => 'ID',
    'User_id'        => '支付用户',
    'Openid'         => '用户OPEN ID',
    'Mch_id'         => '微信商户号',
    'App_id'         => '小程序ID',
    'Out_trade_no'   => '业务单号',
    'Pay_money'      => '支付金额',
    'Transaction_id' => '微信支付流水号',
    'Status'         => '是否已支付',
    'Status 0'       => '否',
    'Status 1'       => '是',
    'Response'       => '支付响应',
    'Payable_id'     => '关联ID',
    'Payable_type'   => '关联模型',
    'Error_message'  => '错误说明',
    'Error_time'     => '错误发生时间',
    'Pay_time'       => '支付时间',
    'Createtime'     => '创建时间',
    'Updatetime'     => '更新时间',
    'User.nickname'  => '昵称',
    'User.avatar'    => '头像'
];
