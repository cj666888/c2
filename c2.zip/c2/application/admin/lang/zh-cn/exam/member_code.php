<?php

return [
    'Member_config_id' => '开通会员类型',
    'Code'             => '激活码',
    'Status'           => '状态',
    'Status 0'         => '未激活',
    'Status 1'         => '已激活',
    'User_id'          => '激活用户',
    'Createtime'       => '创建时间',
    'Updatetime'       => '修改时间',
    'User.nickname'    => '昵称',
    'Config.name'      => '名称'
];
