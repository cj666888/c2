<?php

return [
    'Name'       => '学校名称',
    'Weigh'      => '排序',
    'Status'     => '状态',
    'Status 0'   => '禁用',
    'Status 1'   => '启用',
    'Createtime' => '创建时间',
    'Updatetime' => '修改时间'
];
