<?php

return [
    'Cate_id'       => '题库ID',
    'Code'          => '激活码',
    'Status'        => '状态',
    'Status 0'      => '未激活',
    'Status 1'      => '已激活',
    'User_id'       => '激活用户',
    'Createtime'    => '创建时间',
    'Updatetime'    => '修改时间',
    'Activate_time' => '激活时间',
    'Cate.name'     => '名称',
    'User.nickname' => '昵称',
    'days'          => '开通天数',
];
