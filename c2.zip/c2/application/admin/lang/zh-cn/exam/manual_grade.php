<?php

return [
    'Admin_id'       => '操作管理员',
    'User_id'        => '考试用户',
    'Paper_id'       => '试卷ID',
    'Room_id'        => '考场ID',
    'Kind'           => '种类',
    'Kind paper'     => '试卷',
    'Kind room'      => '考场',
    'Grade_id'       => '考试成绩ID',
    'Question_id'    => '试题ID',
    'Before_score'   => '修改前分数',
    'After_score'    => '修改后分数',
    'Status'         => '状态',
    'Status 0'       => '未生效',
    'Status 1'       => '已生效',
    'Createtime'     => '创建时间',
    'Updatetime'     => '修改时间',
    'Admin.nickname' => '昵称',
    'User.nickname'  => '昵称',
    'Paper.title'    => '试卷名称',
    'Question.title' => '题目'
];
