<?php

return [
    'Name'       => '按钮名称',
    'Icon'       => '按钮图标',
    'Path'       => '跳转页面',
    'Weigh'      => '排序',
    'Status'     => '状态',
    'Status 0'   => '禁用',
    'Set status to 0'=> '设为禁用',
    'Status 1'   => '启用',
    'Set status to 1'=> '设为启用',
    'Createtime' => '创建时间',
    'Updatetime' => '修改时间'
];
