<?php

return [
    'Name'         => '商品标题',
    'Weigh'        => '商品排序',
    'Price'        => '兑换积分',
    'Origin_price' => '商品原价',
    'Stocks'       => '库存',
    'Limit'        => '限购数',
    'Sell_count'   => '已兑数量',
    'Notes'        => '兑换说明',
    'Description'  => '商品详情',
    'Images'       => '图片集合',
    'First_image'  => '商品首图',
    'Status'       => '状态',
    'Status 0'     => '下架',
    'Status 10'    => '上架',
    'Status 20'    => '售罄',
    'Createtime'   => '创建时间',
    'Updatetime'   => '更新时间',
    'Deletetime'   => '删除时间'
];
