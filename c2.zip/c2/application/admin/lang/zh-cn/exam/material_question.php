<?php

return [
    'Parent_question_id' => '材料题主题目',
    'Question_id'        => '材料题子题目',
    'Createtime'         => '创建时间',
    'Updatetime'         => '修改时间',
    'Question.title'     => '题目'
];
