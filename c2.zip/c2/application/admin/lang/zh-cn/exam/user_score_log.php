<?php

return [
    'User_id'       => '会员ID',
    'Score'         => '变更积分',
    'Before'        => '变更前积分',
    'After'         => '变更后积分',
    'Type'          => '变更类型',
    'Memo'          => '备注',
    'Date'          => '日期',
    'Createtime'    => '创建时间',
    'User.nickname' => '昵称',
    'User.avatar'   => '头像'
];
