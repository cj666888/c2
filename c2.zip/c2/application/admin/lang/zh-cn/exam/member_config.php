<?php

return [
    'Id'         => 'ID',
    'Name'       => '名称',
    'Price'      => '价格',
    'Days'       => '天数',
    'Tag'        => '标签',
    'Desc'       => '说明',
    'Status'     => '状态',
    'Status 0'   => '关闭',
    'Status 1'   => '开启',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间',
    'Deletetime' => '删除时间'
];
