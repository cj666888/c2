<?php

return [
    'Id'            => 'ID',
    'User_id'       => '支付用户',
    'Order_no'      => '订单编号',
    'Paper_id'      => '试卷',
    'Amount'        => '订单金额',
    'Status'        => '状态',
    'Status 0'      => '未支付',
    'Status 1'      => '已支付未使用',
    'Status 2'      => '已使用',
    'Pay_money'     => '支付金额',
    'Pay_time'      => '支付时间',
    'Createtime'    => '创建时间',
    'Updatetime'    => '更新时间',
    'User.nickname' => '用户昵称',
    'Paper.title'   => '试卷'
];
