<?php

return [
    'Level'      => '层级',
    'Name'       => '名称',
    'Icon'       => '图标',
    'Parent_id'  => '父级',
    'Weigh'      => '排序',
    'Remark'     => '简介',
    'Status'     => '状态',
    'Status 0'   => '禁用',
    'Set status to 0'=> '设为禁用',
    'Status 1'   => '启用',
    'Set status to 1'=> '设为启用',
    'Createtime' => '创建时间',
    'Updatetime' => '修改时间',
    'Deletetime' => '删除时间'
];
