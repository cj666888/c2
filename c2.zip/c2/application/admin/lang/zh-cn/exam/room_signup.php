<?php

return [
    'Room_id'       => '所属考场',
    'User_id'       => '报名用户',
    'Real_name'     => '真实姓名',
    'Phone'         => '手机号码',
    'Message'       => '审核说明',
    'Status'        => '状态',
    'Status 0'      => '未审核',
    'Status 1'      => '报名成功',
    'Status 2'      => '报名被拒绝',
    'Createtime'    => '创建时间',
    'Updatetime'    => '修改时间',
    'Room.name'     => '考场标题',
    'User.nickname' => '昵称',
    'school_id'     => '所属学校',
    'class_name'    => '班级',
];
