<?php

namespace app\admin\controller\exam;

use addons\exam\enum\PaperMode;
use app\admin\model\exam\PaperQuestionModel;
use app\admin\model\exam\QuestionModel;
use app\common\controller\Backend;
use think\Db;
use think\exception\PDOException;
use think\exception\ValidateException;

/**
 * 试卷
 * @icon fa fa-circle-o
 */
class Paper extends Backend
{

    /**
     * PaperModel模型对象
     * @var \app\admin\model\exam\PaperModel
     */
    protected $model = null;

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\exam\PaperModel;
        $this->view->assign("modeList", $this->model->getModeList());
        $this->view->assign("kindList", $this->model->getKindList());
        $this->view->assign("statusList", $this->model->getStatusList());
        $this->view->assign("usesList", $this->model->getUsesList());
    }



    /**
     * 默认生成的控制器所继承的父类中有index/add/edit/del/multi五个基础方法、destroy/restore/recyclebin三个回收站方法
     * 因此在当前控制器中可不用编写增删改查的代码,除非需要自己控制这部分逻辑
     * 需要将application/admin/library/traits/Backend.php中对应的方法复制到当前控制器,然后进行修改
     */


    /**
     * 查看
     */
    public function index()
    {
        //当前是否为关联查询
        $this->relationSearch = true;
        //设置过滤方法
        $this->request->filter(['strip_tags', 'trim']);
        if ($this->request->isAjax()) {
            //如果发送的来源是Selectpage，则转发到Selectpage
            if ($this->request->request('keyField')) {
                return $this->selectpage();
            }
            list($where, $sort, $order, $offset, $limit) = $this->buildparams();

            $list = $this->model
                ->with(['cate', 'subject'])
                ->where($where)
                ->order($sort, $order)
                ->paginate($limit);

            foreach ($list as $row) {

                $row->getRelation('cate')->visible(['name']);
            }

            $result = array("total" => $list->total(), "rows" => $list->items());

            return json($result);
        }
        return $this->view->fetch();
    }

    /**
     * 添加
     */
    public function add()
    {
        if ($this->request->isPost()) {
            $params = $this->request->post("row/a");
            if ($params) {
                $params = $this->preExcludeFields($params);
                $this->valid($params);

                if ($this->dataLimit && $this->dataLimitFieldAutoFill) {
                    $params[$this->dataLimitField] = $this->auth->id;
                }
                $result = false;
                Db::startTrans();
                try {
                    //是否采用模型验证
                    if ($this->modelValidate) {
                        $name     = str_replace("\\model\\", "\\validate\\", get_class($this->model));
                        $validate = is_bool($this->modelValidate) ? ($this->modelSceneValidate ? $name . '.add' : $name) : $this->modelValidate;
                        $this->model->validateFailException(true)->validate($validate);
                    }
                    // dd($params);
                    $result = $this->model->allowField(true)->save($params);

                    // 保存试卷固定题目
                    $this->saveFixQuestion($this->model, $params);
                    Db::commit();
                } catch (ValidateException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (PDOException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (\Exception $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                }
                if ($result !== false) {
                    $this->success();
                } else {
                    $this->error(__('No rows were inserted'));
                }
            }
            $this->error(__('Parameter %s can not be empty', ''));
        }
        return $this->view->fetch();
    }

    /**
     * 编辑
     */
    public function edit($ids = null)
    {
        $row = $this->model->get($ids);
        if (!$row) {
            $this->error(__('No Results were found'));
        }
        $adminIds = $this->getDataLimitAdminIds();
        if (is_array($adminIds)) {
            if (!in_array($row[$this->dataLimitField], $adminIds)) {
                $this->error(__('You have no permission'));
            }
        }
        if ($this->request->isPost()) {
            $params = $this->request->post("row/a");
            if ($params) {
                $this->valid($params);
                $params = $this->preExcludeFields($params);
                $result = false;
                Db::startTrans();
                try {
                    //是否采用模型验证
                    if ($this->modelValidate) {
                        $name     = str_replace("\\model\\", "\\validate\\", get_class($this->model));
                        $validate = is_bool($this->modelValidate) ? ($this->modelSceneValidate ? $name . '.edit' : $name) : $this->modelValidate;
                        $row->validateFailException(true)->validate($validate);
                    }
                    $result = $row->allowField(true)->save($params);

                    // 保存试卷固定题目
                    $this->saveFixQuestion($row, $params, 'edit');
                    Db::commit();
                } catch (ValidateException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (PDOException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (\Exception $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                }
                if ($result !== false) {
                    $this->success();
                } else {
                    $this->error(__('No rows were updated'));
                }
            }
            $this->error(__('Parameter %s can not be empty', ''));
        }

        if ($row['mode'] == PaperMode::FIX) {
            $row['questions'] = QuestionModel::getFixListByPaper($row['id'], ['cates']);
        }
        $this->view->assign("row", $row);
        $this->view->assign("configs", json_decode($row['configs'], true));
        return $this->view->fetch();
    }

    /**
     * 验证参数
     * @param $params
     * @return void
     */
    protected function valid(&$params)
    {
        if ($params['pass_score'] > $params['total_score']) {
            $this->error('及格分数不能大于总分');
        }

        $params['start_time'] = $params['start_time'] ?: 0;
        $params['end_time']   = $params['end_time'] ?: 0;

        if ($params['start_time']) {
            if ($params['start_time'] > $params['end_time']) {
                $this->error('开始时间不能大于结束时间');
            }
            // if (strtotime($params['start_time']) < time()) {
            //     $this->error('开始时间不能小于当前时间');
            // }
        }
        if ($params['end_time']) {
            if (!$params['start_time']) {
                $this->error('请先选择开始时间');
            }
        }

        // 固定选题模式
        if ($params['mode'] == 'FIX') {
            $params['questions'] = json_decode($params['questions'], true);
            if (!$params['questions']) {
                $this->error('请先选择题目');
            }
            if (count($params['questions']) < $params['quantity']) {
                $this->error('题目数量不能大于题目总数');
            }
        }

        $limit_time = 0;
        if ($params['limit_time_hour']) {
            $limit_time += $params['limit_time_hour'] * 60 * 60;
        }
        if ($params['limit_time_minute']) {
            $limit_time += $params['limit_time_minute'] * 60;
        }
        $params['limit_time'] = $limit_time;

        if ($params['is_prevent_switch_screen']) {
            if (empty($params['switch_screen_count']) || $params['switch_screen_count'] < 1) {
                $this->error('切屏次数不能小于1');
            }
            if (empty($params['switch_screen_second']) || $params['switch_screen_second'] < 1) {
                $this->error('切屏认定秒数不能小于1');
            }
        }
    }

    /**
     * 保存固定选题
     * @param $paper
     * @param $params
     * @return void
     */
    protected function saveFixQuestion($paper, $params, $method = 'add')
    {
        if ($paper['mode'] != 'FIX') {
            return;
        }

        if ($method == 'edit') {
            PaperQuestionModel::where('paper_id', $paper['id'])->delete();
        }

        $questions = $params['questions'];
        $data      = [];
        foreach ($questions as $key => $question) {
            // $item = [
            //     'paper_id'    => $paper['id'],
            //     'question_id' => $question['id'],
            //     'score'       => $question['score'],
            //     'sort'        => $key + 1,
            //     'createtime'  => time(),
            // ];
            //
            // if ($question['kind'] == 'SHORT') {
            //     $item['answer'] = $question['answer'];
            // }

            // $data[] = $item;
            $data[] = [
                'paper_id'      => $paper['id'],
                'question_id'   => $question['id'],
                'score'         => $question['score'],
                'answer_config' => is_array($question['answer']) ? json_encode($question['answer'], JSON_UNESCAPED_UNICODE) : $question['answer'],
                'sort'          => $key + 1,
                'createtime'    => time(),
            ];
        }

        (new PaperQuestionModel())->saveAll($data);
    }
}
